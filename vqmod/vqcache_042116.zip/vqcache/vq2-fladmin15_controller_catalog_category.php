<?php 
class ControllerCatalogCategory extends Controller { 
	private $error = array();
 
public function export() {
			
				$this->load->model('catalog/category');
				
				$categories= array();
				
				$data =array();
		
				$results = $this->model_catalog_category->getCategories($data);

				foreach ($results as $result) {
		
					$categories[] = array(
						'category_id' => $result['category_id'],
						'name'        => $result['name'],
						'sort_order'  => $result['sort_order']
					);
				}	
						
						$categories_data = array();
						
						$categories_column=array();
						
						$categories_column = array('Category ID', 'Category Name', 'Sort Order');
							
						$categories_data[0]=   $categories_column;   
						
						foreach($categories as $categories_row)
						{
							$categories_data[]=   $categories_row;            
						}     
						require_once(DIR_SYSTEM . 'library/excel_xml.php');
						$xls = new Excel_XML('UTF-8', false, 'Category List');
						
						$xls->addArray($categories_data);
						
						$xls->generateXML('category_list_'.date('Y-m-d _ H:i:s'));	

					}
	public function index() {
		$this->language->load('catalog/category');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('catalog/category');
		 
		$this->getList();
	}

	public function insert() {

			if ($this->request->server['REQUEST_METHOD'] == 'POST') { //uuu
			if (isset($this->request->post['used_auto_meta']) && is_array($this->request->post['used_auto_meta'])) {
				foreach ($this->request->post['used_auto_meta'] as $key => $value) {
					if ($value == 'checked') {
						if ($this->config->get('useo_num') ) $num = (int)$this->config->get('useo_num');
						else $num = 180;
						$meta_description = substr(strip_tags(html_entity_decode($this->request->post['category_description'][$key]['description'])),0,$num);
						$meta_description = trim(preg_replace('/[ ]{2,}|[\t]/', ' ', $meta_description));							
						$this->request->post['category_description'][$key]['meta_description'] = $meta_description;	
						$meta_keywords = preg_replace("/[^A-Za-z0-9 ]/", ' ', $this->request->post['category_description'][$key]['name']);
						$meta_keywords = explode(' ',$meta_keywords);
						foreach($meta_keywords as $m_key => $m_value) {
							$m_value = trim($m_value);
							if (empty($m_value) ) unset($meta_keywords[$m_key]);
							else $meta_keywords[$m_key] = $m_value;
						}	
						$meta_keywords = implode(",",$meta_keywords);
						$this->request->post['category_description'][$key]['meta_keyword'] = $meta_keywords;
					}
				}
			}
		}
			
		$this->language->load('catalog/category');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('catalog/category');
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			if (!isset($this->request->post['keyword']) || empty($this->request->post['keyword']) ) { //uuu
				$u_non_alpha = '/[,]|[\']|[`]|[~]|[!]|[@]|[#]|[$]|[%]|[\^]|[&]|[*]|[(]|[)]|[_]|[-]|[{]|[}]|[\"]|[?]|[\\\]|[\|]|[\/]|[+]|[=]|[\[]|[\]]|[;]|[:]|[>]|[.]|[<]/';
				$u_lang = $this->config->get('config_language_id');
				$u_keyword = html_entity_decode($this->request->post['category_description'][$u_lang]['name']);
				$u_keyword = preg_replace($u_non_alpha, '',$u_keyword);
				$u_keyword = trim(preg_replace('/[ ]{2,}|[\t]/', ' ', $u_keyword) );
				$u_keyword = preg_replace('/[ ]/','-',$u_keyword);
				
				if (empty($u_keyword) ) $u_keyword = 'category';
				while(true) {
					$u_query = $this->db->query("SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE keyword = '" . $this->db->escape("$u_keyword") ."'");
					if ($u_query->num_rows) {
						$u_keyword = $u_keyword.rand(1,9);
					}
					else {
						break;
					}
				}
				$this->request->post['keyword'] = $u_keyword;
			}
			
			$this->model_catalog_category->addCategory($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
						
			$this->redirect($this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url, 'SSL')); 
		}

		$this->getForm();
	}

	public function update() {

			if ($this->request->server['REQUEST_METHOD'] == 'POST') { //uuu
			if (isset($this->request->post['used_auto_meta']) && is_array($this->request->post['used_auto_meta'])) {
				foreach ($this->request->post['used_auto_meta'] as $key => $value) {
					if ($value == 'checked') {
						if ($this->config->get('useo_num') ) $num = (int)$this->config->get('useo_num');
						else $num = 180;
						$meta_description = substr(strip_tags(html_entity_decode($this->request->post['category_description'][$key]['description'])),0,$num);
						$meta_description = trim(preg_replace('/[ ]{2,}|[\t]/', ' ', $meta_description));							
						$this->request->post['category_description'][$key]['meta_description'] = $meta_description;	
						$meta_keywords = preg_replace("/[^A-Za-z0-9 ]/", ' ', $this->request->post['category_description'][$key]['name']);
						$meta_keywords = explode(' ',$meta_keywords);
						foreach($meta_keywords as $m_key => $m_value) {
							$m_value = trim($m_value);
							if (empty($m_value) ) unset($meta_keywords[$m_key]);
							else $meta_keywords[$m_key] = $m_value;
						}	
						$meta_keywords = implode(",",$meta_keywords);
						$this->request->post['category_description'][$key]['meta_keyword'] = $meta_keywords;
					}
				}
			}
		}
			
		$this->language->load('catalog/category');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('catalog/category');
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_catalog_category->editCategory($this->request->get['category_id'], $this->request->post);
			
			$this->session->data['success'] = $this->language->get('text_success');
			
			$url = '';

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
						
			$this->redirect($this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function delete() {
		$this->language->load('catalog/category');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('catalog/category');
		
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $category_id) {
				$this->model_catalog_category->deleteCategory($category_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');
			
			$url = '';

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			$this->redirect($this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}
		
		$this->getList();
	}
	
	public function repair() {
		$this->language->load('catalog/category');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('catalog/category');
		
		if ($this->validateRepair()) {
			$this->model_catalog_category->repairCategories();

			$this->session->data['success'] = $this->language->get('text_success');
			
			$this->redirect($this->url->link('catalog/category', 'token=' . $this->session->data['token'], 'SSL'));
		}
		
		$this->getList();	
	}
	
	protected function getList() {
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		$url = '';
		
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
						
   		$this->data['breadcrumbs'] = array();

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url, 'SSL'),
      		'separator' => ' :: '
   		);
									
		$this->data['insert'] = $this->url->link('catalog/category/insert', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$this->data['delete'] = $this->url->link('catalog/category/delete', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$this->data['repair'] = $this->url->link('catalog/category/repair', 'token=' . $this->session->data['token'] . $url, 'SSL');
		
		$this->data['categories'] = array();
		
		$data = array(
			'start' => ($page - 1) * $this->config->get('config_admin_limit'),
			'limit' => $this->config->get('config_admin_limit')
		);
				
		$category_total = $this->model_catalog_category->getTotalCategories();
		
		$results = $this->model_catalog_category->getCategories($data);

		foreach ($results as $result) {
			$action = array();
						
			$action[] = array(
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('catalog/category/update', 'token=' . $this->session->data['token'] . '&category_id=' . $result['category_id'] . $url, 'SSL')
			);

			$this->data['categories'][] = array(
				'category_id' => $result['category_id'],
				'name'        => $result['name'],
				'sort_order'  => $result['sort_order'],
				'selected'    => isset($this->request->post['selected']) && in_array($result['category_id'], $this->request->post['selected']),
				'action'      => $action
			);
		}
		
		$this->data['heading_title'] = $this->language->get('heading_title');

		$this->data['text_no_results'] = $this->language->get('text_no_results');

		$this->data['column_name'] = $this->language->get('column_name');
		$this->data['column_sort_order'] = $this->language->get('column_sort_order');
		$this->data['column_action'] = $this->language->get('column_action');

$this->data['button_export'] = $this->language->get('button_export');
			$this->data['export'] = $this->url->link('catalog/category/export', 'token=' . $this->session->data['token'], 'SSL');
		$this->data['button_insert'] = $this->language->get('button_insert');
		$this->data['button_delete'] = $this->language->get('button_delete');
 		$this->data['button_repair'] = $this->language->get('button_repair');
 
 		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];
		
			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}
		
		$pagination = new Pagination();
		$pagination->total = $category_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_admin_limit');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');
			
		$this->data['pagination'] = $pagination->render();
		
		$this->template = 'catalog/category_list.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);
				
		$this->response->setOutput($this->render());
	}

	protected function getForm() {
		$this->data['heading_title'] = $this->language->get('heading_title');

		$this->data['text_none'] = $this->language->get('text_none');
		$this->data['text_default'] = $this->language->get('text_default');
		$this->data['text_image_manager'] = $this->language->get('text_image_manager');
		$this->data['text_browse'] = $this->language->get('text_browse');
		$this->data['text_clear'] = $this->language->get('text_clear');		
		$this->data['text_enabled'] = $this->language->get('text_enabled');
    	$this->data['text_disabled'] = $this->language->get('text_disabled');
		$this->data['text_percent'] = $this->language->get('text_percent');
		$this->data['text_amount'] = $this->language->get('text_amount');
				
		$this->data['entry_name'] = $this->language->get('entry_name');
		$this->data['entry_meta_keyword'] = $this->language->get('entry_meta_keyword');
		$this->data['entry_meta_keyword'] = $this->language->get('entry_meta_keyword');
		$this->data['entry_filterprice_range'] = $this->language->get('entry_filterprice_range');

		$this->data['entry_meta_description'] = $this->language->get('entry_meta_description');
		$this->data['entry_description'] = $this->language->get('entry_description');
		$this->data['entry_parent'] = $this->language->get('entry_parent');
		$this->data['entry_filter'] = $this->language->get('entry_filter');
		$this->data['entry_store'] = $this->language->get('entry_store');
		$this->data['entry_keyword'] = $this->language->get('entry_keyword');
		$this->data['entry_image'] = $this->language->get('entry_image');
		$this->data['entry_top'] = $this->language->get('entry_top');
		$this->data['entry_column'] = $this->language->get('entry_column');		
		$this->data['entry_sort_order'] = $this->language->get('entry_sort_order');
		$this->data['entry_status'] = $this->language->get('entry_status');
		$this->data['entry_layout'] = $this->language->get('entry_layout');
		
		$this->data['button_save'] = $this->language->get('button_save');
		$this->data['button_cancel'] = $this->language->get('button_cancel');

    	$this->data['tab_general'] = $this->language->get('tab_general');
    	$this->data['tab_data'] = $this->language->get('tab_data');
		$this->data['tab_design'] = $this->language->get('tab_design');
		
		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$this->data['uksbhome'] = 'https://www.secureserverssl.co.uk/opencart-extensions/google-merchant/';
		}else{
			$this->data['uksbhome'] = 'http://www.opencart-extensions.co.uk/google-merchant/';
		}

		$this->language->load('feed/uksb_google_merchant');
		// Google Merchant
		$this->data['tab_google'] = $this->language->get('tab_google');
		$this->data['entry_p_google_category'] = $this->language->get('entry_p_google_category');
		$this->data['entry_choose_google_category'] = $this->language->get('entry_choose_google_category');
		$this->data['entry_choose_google_category_xml'] = $this->language->get('entry_choose_google_category_xml');
		$this->data['help_p_google_category'] = $this->language->get('help_p_google_category');
		$this->data['warning_nogpc'] = $this->language->get('warning_nogpc');
		$this->language->load('catalog/category');
		
 		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}
	
 		if (isset($this->error['name'])) {
			$this->data['error_name'] = $this->error['name'];
		} else {
			$this->data['error_name'] = array();
		}

  		$this->data['breadcrumbs'] = array();

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('catalog/category', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
		
		if (!isset($this->request->get['category_id'])) {
			$this->data['action'] = $this->url->link('catalog/category/insert', 'token=' . $this->session->data['token'], 'SSL');
		} else {
			$this->data['action'] = $this->url->link('catalog/category/update', 'token=' . $this->session->data['token'] . '&category_id=' . $this->request->get['category_id'], 'SSL');
		}
		
		$this->data['cancel'] = $this->url->link('catalog/category', 'token=' . $this->session->data['token'], 'SSL');

		if (isset($this->request->get['category_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
      		$category_info = $this->model_catalog_category->getCategory($this->request->get['category_id']);
    	}
		
		$this->data['token'] = $this->session->data['token'];
		
		$this->load->model('localisation/language');
		
		$this->data['languages'] = $this->model_localisation_language->getLanguages();

		if (isset($this->request->post['category_description'])) {
			$this->data['category_description'] = $this->request->post['category_description'];
		} elseif (isset($this->request->get['category_id'])) {
			$this->data['category_description'] = $this->model_catalog_category->getCategoryDescriptions($this->request->get['category_id']);
		} else {
			$this->data['category_description'] = array();
		}

		if (isset($this->request->post['path'])) {
			$this->data['path'] = $this->request->post['path'];
		} elseif (!empty($category_info)) {
			$this->data['path'] = $category_info['path'];
		} else {
			$this->data['path'] = '';
		}
		
		if (isset($this->request->post['parent_id'])) {
			$this->data['parent_id'] = $this->request->post['parent_id'];
		} elseif (!empty($category_info)) {
			$this->data['parent_id'] = $category_info['parent_id'];
		} else {
			$this->data['parent_id'] = 0;
		}

		$this->load->model('catalog/filter');
		
		if (isset($this->request->post['category_filter'])) {
			$filters = $this->request->post['category_filter'];
		} elseif (isset($this->request->get['category_id'])) {		
			$filters = $this->model_catalog_category->getCategoryFilters($this->request->get['category_id']);
		} else {
			$filters = array();
		}
	
		$this->data['category_filters'] = array();
		
		foreach ($filters as $filter_id) {
			$filter_info = $this->model_catalog_filter->getFilter($filter_id);
			
			if ($filter_info) {
				$this->data['category_filters'][] = array(
					'filter_id' => $filter_info['filter_id'],
					'name'      => $filter_info['group'] . ' &gt; ' . $filter_info['name']
				);
			}
		}	
										
		$this->load->model('setting/store');
		
		$this->data['stores'] = $this->model_setting_store->getStores();
		
		if (isset($this->request->post['category_store'])) {
			$this->data['category_store'] = $this->request->post['category_store'];
		} elseif (isset($this->request->get['category_id'])) {
			$this->data['category_store'] = $this->model_catalog_category->getCategoryStores($this->request->get['category_id']);
		} else {
			$this->data['category_store'] = array(0);
		}			
		
		if (isset($this->request->post['keyword'])) {
			$this->data['keyword'] = $this->request->post['keyword'];
		} elseif (!empty($category_info)) {
			$this->data['keyword'] = $category_info['keyword'];
		} else {
			$this->data['keyword'] = '';
		}

		if (isset($this->request->post['image'])) {
			$this->data['image'] = $this->request->post['image'];
		} elseif (!empty($category_info)) {
			$this->data['image'] = $category_info['image'];
		} else {
			$this->data['image'] = '';
		}
		
		$this->load->model('tool/image');

		if (isset($this->request->post['image']) && file_exists(DIR_IMAGE . $this->request->post['image'])) {
			$this->data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
		} elseif (!empty($category_info) && $category_info['image'] && file_exists(DIR_IMAGE . $category_info['image'])) {
			$this->data['thumb'] = $this->model_tool_image->resize($category_info['image'], 100, 100);
		} else {
			$this->data['thumb'] = $this->model_tool_image->resize('no_image.jpg', 100, 100);
		}
		
		$this->data['no_image'] = $this->model_tool_image->resize('no_image.jpg', 100, 100);
		
		if (isset($this->request->post['top'])) {
			$this->data['top'] = $this->request->post['top'];
		} elseif (!empty($category_info)) {
			$this->data['top'] = $category_info['top'];
		} else {
			$this->data['top'] = 0;
		}
		
		if (isset($this->request->post['column'])) {
			$this->data['column'] = $this->request->post['column'];
		} elseif (!empty($category_info)) {
			$this->data['column'] = $category_info['column'];
		} else {
			$this->data['column'] = 1;
		}
				
		if (isset($this->request->post['sort_order'])) {
			$this->data['sort_order'] = $this->request->post['sort_order'];
		} elseif (!empty($category_info)) {
			$this->data['sort_order'] = $category_info['sort_order'];
		} else {
			$this->data['sort_order'] = 0;
		}
		
		if (isset($this->request->post['status'])) {
			$this->data['status'] = $this->request->post['status'];
		} elseif (!empty($category_info)) {
			$this->data['status'] = $category_info['status'];
		} else {
			$this->data['status'] = 1;
		}
		
		if (isset($this->request->post['google_category_gb'])) {
			$this->data['google_category_gb'] = $this->request->post['google_category_gb'];
			$this->data['google_category_us'] = $this->request->post['google_category_us'];
			$this->data['google_category_au'] = $this->request->post['google_category_au'];
			$this->data['google_category_fr'] = $this->request->post['google_category_fr'];
			$this->data['google_category_de'] = $this->request->post['google_category_de'];
			$this->data['google_category_it'] = $this->request->post['google_category_it'];
			$this->data['google_category_nl'] = $this->request->post['google_category_nl'];
			$this->data['google_category_es'] = $this->request->post['google_category_es'];
			$this->data['google_category_pt'] = $this->request->post['google_category_pt'];
			$this->data['google_category_cz'] = $this->request->post['google_category_cz'];
			$this->data['google_category_jp'] = $this->request->post['google_category_jp'];
			$this->data['google_category_dk'] = $this->request->post['google_category_dk'];
			$this->data['google_category_no'] = $this->request->post['google_category_no'];
			$this->data['google_category_pl'] = $this->request->post['google_category_pl'];
			$this->data['google_category_ru'] = $this->request->post['google_category_ru'];
			$this->data['google_category_sv'] = $this->request->post['google_category_sv'];
			$this->data['google_category_tr'] = $this->request->post['google_category_tr'];
		} elseif (!empty($category_info)) {
			$this->data['google_category_gb'] = $category_info['google_category_gb'];
			$this->data['google_category_us'] = $category_info['google_category_us'];
			$this->data['google_category_au'] = $category_info['google_category_au'];
			$this->data['google_category_fr'] = $category_info['google_category_fr'];
			$this->data['google_category_de'] = $category_info['google_category_de'];
			$this->data['google_category_it'] = $category_info['google_category_it'];
			$this->data['google_category_nl'] = $category_info['google_category_nl'];
			$this->data['google_category_es'] = $category_info['google_category_es'];
			$this->data['google_category_pt'] = $category_info['google_category_pt'];
			$this->data['google_category_cz'] = $category_info['google_category_cz'];
			$this->data['google_category_jp'] = $category_info['google_category_jp'];
			$this->data['google_category_dk'] = $category_info['google_category_dk'];
			$this->data['google_category_no'] = $category_info['google_category_no'];
			$this->data['google_category_pl'] = $category_info['google_category_pl'];
			$this->data['google_category_ru'] = $category_info['google_category_ru'];
			$this->data['google_category_sv'] = $category_info['google_category_sv'];
			$this->data['google_category_tr'] = $category_info['google_category_tr'];
		} else {
			$this->data['google_category_gb'] = '';
			$this->data['google_category_us'] = '';
			$this->data['google_category_au'] = '';
			$this->data['google_category_fr'] = '';
			$this->data['google_category_de'] = '';
			$this->data['google_category_it'] = '';
			$this->data['google_category_nl'] = '';
			$this->data['google_category_es'] = '';
			$this->data['google_category_pt'] = '';
			$this->data['google_category_cz'] = '';
			$this->data['google_category_jp'] = '';
			$this->data['google_category_dk'] = '';
			$this->data['google_category_no'] = '';
			$this->data['google_category_pl'] = '';
			$this->data['google_category_ru'] = '';
			$this->data['google_category_sv'] = '';
			$this->data['google_category_tr'] = '';
		}
				
		if (isset($this->request->post['category_layout'])) {
			$this->data['category_layout'] = $this->request->post['category_layout'];
		} elseif (isset($this->request->get['category_id'])) {
			$this->data['category_layout'] = $this->model_catalog_category->getCategoryLayouts($this->request->get['category_id']);
		} else {
			$this->data['category_layout'] = array();
		}

		$this->load->model('design/layout');
		
		$this->data['layouts'] = $this->model_design_layout->getLayouts();
						

			if (isset($this->request->post['useo_auto_meta'])) { //uuu
			$this->data['useo_auto_meta'] = $this->request->post['useo_auto_meta'];
		} elseif ($this->config->get('useo_auto_meta') && $this->config->get('useo_auto_meta') == 'yes' && is_array($this->data['category_description']) ) {
			$useo_temp = $this->data['languages'];
			foreach ($useo_temp as $us) {
				$this->data['useo_auto_meta'][$us['language_id']] = 'checked';
			}
		} else {
			$this->data['useo_auto_meta'] = array();
		}
		if ($this->config->get('useo_meta_num') ) //uuu
			$this->data['useo_meta_num'] = $this->config->get('useo_meta_num');
		else
			$this->data['useo_meta_num'] = '180';
			
		$this->template = 'catalog/category_form.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);
				
		$this->response->setOutput($this->render());
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'catalog/category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		foreach ($this->request->post['category_description'] as $language_id => $value) {
			if ((utf8_strlen($value['name']) < 2) || (utf8_strlen($value['name']) > 255)) {
				$this->error['name'][$language_id] = $this->language->get('error_name');
			}
		}
		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
					
		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}
	
	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'catalog/category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
 
		if (!$this->error) {
			return true; 
		} else {
			return false;
		}
	}
	
	protected function validateRepair() {
		if (!$this->user->hasPermission('modify', 'catalog/category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
 
		if (!$this->error) {
			return true; 
		} else {
			return false;
		}
	}
			
	public function autocomplete() {
		$json = array();
		
		if (isset($this->request->get['filter_name'])) {
			$this->load->model('catalog/category');
			
			$data = array(
				'filter_name' => $this->request->get['filter_name'],
				'start'       => 0,
				'limit'       => 20
			);
			
			$results = $this->model_catalog_category->getCategories($data);
				
			foreach ($results as $result) {
				$json[] = array(
					'category_id' => $result['category_id'], 
					'name'        => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}		
		}

		$sort_order = array();
	  
		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->setOutput(json_encode($json));
	}		
}
?>