<?php  
class ControllerCommonHome extends Controller {

	public function index() {
		$this->document->setTitle($this->config->get('config_title'));
		$this->document->setDescription($this->config->get('config_meta_description'));
		
		

		if ($this->config->get('config_keywords')) {
			$this->document->setKeywords($this->config->get('config_keywords'));
		
		}
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/common/home.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/common/home.tpl';
		} else {
			$this->template = 'default/template/common/home.tpl';
		}
		
		$this->children = array(
			'common/column_left',
			'common/column_right',
			'common/content_top',
			'common/content_bottom',
			'common/footer',
			'common/header',
			'common/offer_slideshow',
		);
										
		$this->response->setOutput($this->render());
	}

	public function page404() {
		$this->document->setTitle($this->config->get('config_title'));
		$this->document->setDescription($this->config->get('config_meta_description'));

		if ($this->config->get('config_keywords')) {
			$this->document->setKeywords($this->config->get('config_keywords'));
		
		}
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/common/page404.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/common/page404.tpl';
		} else {
			$this->template = 'default/template/common/home.tpl'; 
		} 
		
		$this->children = array( 
			'common/column_left',
			'common/column_right',
			'common/content_top',
			'common/content_bottom',
			'common/footer',
			'common/header',
			'common/offer_slideshow',
		);
										
		$this->response->setOutput($this->render());
	}
	public function emailus()//email us
	{
	$username=$this->request->post['username'];
	$comment=$this->request->post['comment'];
        $emailid=$this->request->post['emailid'];
        $productname=$this->request->post['productname'];  
        $phoneno=$this->request->post['phoneno'];  
        $to=' order@footlounge.in';            
   
       $subject='Product Enquiry';
        $message="Dear Admin,<br/><p>You have received an enquiry for the below product.</p><br/>Name:&nbsp; ".$username."<br/>Product:&nbsp; ".$productname."<br/>Phone Number: &nbsp; ".$phoneno."<br/>Comment:&nbsp; ".$comment."<br/>Email : &nbsp; ".$emailid."<br/><br/>Thank you.";

//$headers = "From: webmaster@example.com\r\n";

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
$headers .= 'From: order@footlounge.in' . "\r\n";

/*// Always set content-type when sending HTML email
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'X-Mailer: PHP/' . phpversion();  
// More headers
$headers .= 'From: info@tech-bee.com' . "\r\n";  */

if(mail($to,$subject,$message,$headers)) echo 1; else echo 0;   
  

	} 
}
?>